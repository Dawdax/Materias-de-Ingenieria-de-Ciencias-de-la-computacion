<?php
   class Ejemplo extends CI_Controller{
      function index(){
         echo "<h3>Hola estudiantes de Lenguajes Interpretados en el Servidor</h3>";
      }
   }
?>
