<?php
   class peliculas extends CI_Controller{
      function index(){
         //Invocar al modelo que realizará la consulta en la tabla
      	 //peliculas
         $this->load->model('peliculas_model');
         //Los datos que sean obtenidos se cargarán en la matriz
         //asociativa $data con índice 'rows'
         $data['rows'] = $this->peliculas_model->getAll();
         //Cargar la vista y pasarle los datos devueltos por el modelo
         $this->load->view('peliculas_view', $data);
      }
   }
?>