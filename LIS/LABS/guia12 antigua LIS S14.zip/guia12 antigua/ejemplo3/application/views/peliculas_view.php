<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="utf-8" />
   <title>Base de datos de películas</title>
   <link rel="stylesheet" href="<?=PATH;?>css/tablas.css" />
</head>
<body>
<section>
<article>
<div id="container">
   <?php
      $tabla  = "<table class=\"tablaps\">\n";
      $tabla .= "<thead>\n\t<tr>\n\t\t<th>\n\t\t\tPOSTER\n\t\t</th>\n\t\t";
      $tabla .= "<th>\n\t\t\tCARACTERISTICAS\n\t\t</th>\n\t\t";
      $contador = 1;
      foreach($rows as $movie):
         if($contador % 2 == 1) $clase = "impar";
         else $clase = "par";
         $tabla .= "<tr class=\"" . $clase . "\">\n\t\t";
         $tabla .= "<td>\n\t\t\t<img src=\"" . PATH . $movie->imgpelicula . "\" alt=\"" . $movie->titulopelicula . "\" />\n\t\t</td>\n\t\t";
         $tabla .= "<td class='caracteristicas'>\n\t\t\t <h1 class='titulo'>" . $movie->titulopelicula . "<h1><br>";
         $tabla .= "\n\t\t\t SINOPSIS:" . $movie->descripcion . "\n\t\t\n<br>";
         $tabla .= "\n\t\t\t DIRECTOR:" . $movie->nombre . "\n\t\t\n\t\t<br>";
         $tabla .= "\n\t\t\t GENERO:" . $movie->generopelicula . "\n\t\t\n\t\t<br>";
         $tabla .= "\n\t\t\t DURACIÓN:" . $movie->duracion . " min\t\t</td>\n\t\t</tr>\n";
         $contador++;
      endforeach;
      $tabla .= "</tbody>\n";
      $tabla .= "</table>\n";
      echo $tabla;
   ?>
</div>
</article>
</section>
</body>
</html>