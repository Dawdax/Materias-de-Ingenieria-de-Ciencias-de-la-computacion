<?php
   class peliculas_model extends CI_Model{
      function getAll(){
         //Construir la consulta a ejecutar en el servidor MySQL
         //Esta consulta involucrará datos de columnas de las tres 
         //tablas (pelicula, genero y director) por lo tanto se hará 
         //uso de la cláusula JOIN para recuperar los datos de las
         //tres columnas que son requeridas
         /*$sql  = "SELECT titulopelicula, descripcion, imgpelicula, nombre, generopelicula, duracion ";
         $sql .= "FROM pelicula "; 
         $sql .= "JOIN genero ON pelicula.idgenero = genero.idgenero "; 
         $sql .= "JOIN director ON pelicula.iddirector = director.iddirector "; 
         //Ejecutar la consulta
         $qr = $this->db->query($sql);*/


         $qr = $this->db->select('titulopelicula, generopelicula, descripcion, imgpelicula, nombre, duracion')
               ->from('pelicula')
               ->join('genero','pelicula.idgenero = genero.idgenero')
               ->join('director', 'pelicula.iddirector = director.iddirector')
               ->get();
               
         //Recorrer el conjunto de resultados con una sentencia
         //repetitiva y almacenar las filas o registros recuperados
         //en la matriz $data que se devolverá al controlador
         if($qr->num_rows() > 0){
            foreach($qr->result() as $row){
               $data[] = $row;
            }
            return $data;
         }
      }
      
      function newMovie(){
         $sql  = "";
      }
   }
?>